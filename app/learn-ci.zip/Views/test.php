<pre>
    <?php
    print_r($data);
    ?>
</pre>